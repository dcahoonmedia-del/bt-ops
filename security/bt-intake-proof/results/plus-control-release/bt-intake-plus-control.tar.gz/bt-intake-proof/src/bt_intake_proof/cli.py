#!/usr/bin/env python3
"""Intake-proof CLI. Stops at the first failed or blocked Google gate."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .constants import MAILBOX, TRANSPORT_CONTACTUS, TRANSPORT_PLUS
from .dispatch import build_constructor
from .cloud_auth import cloud_authorization_url
from .gates import diagnose_google, store_path
from .live_google import contactus_gmail
from .live_receive import receiver_access_token, receive_once
from .receiver import recover_from_cursor
from .oauth_consent import OAuthClientError, authorization_url, blocked_oauth_url, exchange_code
from .scorecard import apply_local_contract_results, empty_scorecard, markdown_table, write_scorecard
from .setup_google import blocked_setup
from .store import ReceiptStore

ROOT = Path(__file__).resolve().parents[2]
RESULTS = ROOT / "results"


def _print(payload: dict) -> None:
    print(json.dumps(payload, indent=2, default=str), flush=True)


def cmd_gate(_args: argparse.Namespace) -> int:
    diagnosis = diagnose_google()
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / "phase1-google-gate.json").write_text(
        json.dumps(diagnosis, indent=2, default=str) + "\n",
        encoding="utf-8",
    )
    scorecard = empty_scorecard(
        "contactus@ Gmail read-only consent passed. Pub/Sub create is blocked on Cloud admin credentials or console-created topic."
    )
    write_scorecard(RESULTS / "scorecard.json", scorecard)
    _print({"google": diagnosis, "setup": blocked_setup(diagnosis), "scorecard_overall": scorecard["overall"]})
    return 0 if diagnosis["status"] == "READY" else 2


def cmd_setup(_args: argparse.Namespace) -> int:
    diagnosis = diagnose_google()
    setup = blocked_setup(diagnosis)
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / "phase1-setup.json").write_text(json.dumps(setup, indent=2, default=str) + "\n", encoding="utf-8")
    _print(setup)
    if setup["status"] != "READY":
        return 2
    return 0


def cmd_scorecard(_args: argparse.Namespace) -> int:
    path = RESULTS / "scorecard.json"
    if not path.exists():
        scorecard = empty_scorecard("Scorecard has not been generated yet.")
    else:
        scorecard = json.loads(path.read_text(encoding="utf-8"))
    print(markdown_table(scorecard), flush=True)
    _print({"overall": scorecard.get("overall"), "stopped_at": scorecard.get("stopped_at")})
    return 0


def cmd_oauth_url(_args: argparse.Namespace) -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    try:
        payload = authorization_url()
    except OAuthClientError:
        payload = blocked_oauth_url()
    (RESULTS / "oauth-url.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    if payload.get("authorization_url"):
        (RESULTS / "AUTH_URL.txt").write_text(payload["authorization_url"] + "\n", encoding="utf-8")
    _print(payload)
    return 0 if payload.get("authorization_url") else 2


def cmd_cloud_oauth_url(_args: argparse.Namespace) -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    try:
        payload = cloud_authorization_url()
    except OAuthClientError as exc:
        payload = {"status": "BLOCKED", "authorization_url": None, "error": str(exc)}
        _print(payload)
        return 2
    safe = dict(payload)
    (RESULTS / "cloud-oauth-url.json").write_text(json.dumps(safe, indent=2) + "\n", encoding="utf-8")
    _print(safe)
    return 0


def cmd_oauth_exchange(args: argparse.Namespace) -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    try:
        payload = exchange_code(args.redirect)
    except OAuthClientError as exc:
        payload = {"status": "FAIL", "error": str(exc)}
        _print(payload)
        return 1
    safe = {k: v for k, v in payload.items() if k != "token_path"}
    (RESULTS / "gmail-consent.json").write_text(json.dumps(safe, indent=2) + "\n", encoding="utf-8")
    _print(safe)
    return 0


def _live_store() -> ReceiptStore:
    return ReceiptStore(store_path())


def cmd_receive_once(_args: argparse.Namespace) -> int:
    RESULTS.mkdir(parents=True, exist_ok=True)
    store = _live_store()
    try:
        payload = receive_once(store, contactus_gmail(), receiver_access_token())
    except OAuthClientError as exc:
        payload = {"status": "FAIL", "error": str(exc)}
        _print(payload)
        return 1
    finally:
        store.close()
    (RESULTS / "live" / "last-receive.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    _print(payload)
    return 0


def cmd_receive_loop(args: argparse.Namespace) -> int:
    import time

    RESULTS.mkdir(parents=True, exist_ok=True)
    store = _live_store()
    try:
        gmail = contactus_gmail()
        sa_token = receiver_access_token()
        started = time.time()
        while True:
            if time.time() - started > 50 * 60:
                gmail = contactus_gmail()
                sa_token = receiver_access_token()
                started = time.time()
            payload = receive_once(store, gmail, sa_token)
            (RESULTS / "live" / "last-receive.json").write_text(
                json.dumps(payload, indent=2) + "\n", encoding="utf-8"
            )
            if payload.get("pulled"):
                _print(payload)
            time.sleep(args.interval)
    except KeyboardInterrupt:
        return 0
    finally:
        store.close()


def cmd_recover(_args: argparse.Namespace) -> int:
    store = _live_store()
    try:
        result = recover_from_cursor(store, contactus_gmail())
    except OAuthClientError as exc:
        payload = {"status": "FAIL", "error": str(exc)}
        _print(payload)
        return 1
    finally:
        store.close()
    safe = {
        "ok": result.get("ok"),
        "acked": result.get("acked"),
        "receipt_count": result.get("receipt_count"),
        "eligible": [
            {
                "gmail_message_id": item.get("gmail_message_id"),
                "thread_id": item.get("thread_id"),
                "classification": item.get("classification"),
                "test_marker": item.get("test_marker"),
                "detection_path": item.get("detection_path"),
            }
            for item in (result.get("eligible") or [])
        ],
        "ineligible_count": len(result.get("ineligible") or []),
        "start_history_id": result.get("start_history_id"),
        "end_history_id": result.get("end_history_id"),
        "detection_path": result.get("detection_path"),
        "commit": {
            k: (result.get("commit") or {}).get(k)
            for k in ("ok", "inserted", "duplicates", "skipped_ineligible", "history_id")
        },
    }
    (RESULTS / "live" / "last-recover.json").write_text(json.dumps(safe, indent=2) + "\n", encoding="utf-8")
    _print(safe)
    return 0 if result.get("ok") else 1


def cmd_write_dispatch_payload(args: argparse.Namespace) -> int:
    store = _live_store()
    try:
        receipts = [item for item in store.eligible_receipts(MAILBOX) if item.get("gmail_message_id") == args.message_id] if args.message_id else store.eligible_receipts(MAILBOX)
    finally:
        store.close()
    if not receipts:
        payload = {"status": "FAIL", "error": "no eligible durable receipt"}
        _print(payload)
        return 1
    receipt = receipts[0]
    nonce = args.nonce or f"bt-intake-{receipt['gmail_message_id']}"
    constructor = build_constructor(receipt, nonce)
    dest = RESULTS / "live" / "codex-payload.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps({"constructor": constructor}, indent=2) + "\n", encoding="utf-8")
    dest.chmod(0o600)
    _print(
        {
            "status": "READY",
            "payload_path": str(dest),
            "gmail_message_id": receipt.get("gmail_message_id"),
            "test_marker": receipt.get("test_marker"),
            "nonce": nonce,
            "tool_name": constructor["tool_name"],
            "namespace": constructor["namespace"],
            "authorization": constructor["authorization"],
        }
    )
    return 0


def cmd_phasee_send_oauth_url(_args: argparse.Namespace) -> int:
    from .contactus_send import send_authorization_url

    RESULTS.mkdir(parents=True, exist_ok=True)
    try:
        payload = send_authorization_url()
    except OAuthClientError as exc:
        payload = {"status": "BLOCKED", "authorization_url": None, "error": str(exc)}
        _print(payload)
        return 2
    (RESULTS / "phasee-send-oauth-url.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    (RESULTS / "SEND_AUTH_URL.txt").write_text(str(payload.get("authorization_url") or "") + "\n", encoding="utf-8")
    _print(payload)
    return 0


def cmd_phasee_send_oauth_exchange(args: argparse.Namespace) -> int:
    from .contactus_send import exchange_send_code

    RESULTS.mkdir(parents=True, exist_ok=True)
    try:
        payload = exchange_send_code(args.redirect)
    except (OAuthClientError, Exception) as exc:
        payload = {"status": "FAIL", "error": str(exc)}
        _print(payload)
        return 1
    safe = {k: v for k, v in payload.items() if k != "token_path"}
    (RESULTS / "phasee-send-consent.json").write_text(json.dumps(safe, indent=2) + "\n", encoding="utf-8")
    _print(safe)
    return 0


def cmd_phasee_execute(args: argparse.Namespace) -> int:
    from .bounded_send import execute_action
    from .cases import CaseLayer
    from .contactus_send import configured_send_transport
    from .send_bind import ensure_send_tables

    RESULTS.mkdir(parents=True, exist_ok=True)
    store = _live_store()
    try:
        layer = CaseLayer(store)
        ensure_send_tables(layer)
        result = execute_action(layer, int(args.action_id), configured_send_transport())
    finally:
        store.close()
    dest = RESULTS / "live" / "phasee-execute.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(result, indent=2, default=str) + "\n", encoding="utf-8")
    _print(result)
    return 0 if result.get("ok") else 2


def cmd_phasee_verify(args: argparse.Namespace) -> int:
    from .cases import CaseLayer
    from .send_bind import ensure_send_tables
    from .send_verify import ContactusReadonlySentVerify, verify_sent

    RESULTS.mkdir(parents=True, exist_ok=True)
    store = _live_store()
    try:
        layer = CaseLayer(store)
        ensure_send_tables(layer)
        result = verify_sent(layer, int(args.action_id), ContactusReadonlySentVerify(contactus_gmail()))
    finally:
        store.close()
    dest = RESULTS / "live" / "phasee-verify-sent.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(result, indent=2, default=str) + "\n", encoding="utf-8")
    _print(result)
    return 0 if result.get("ok") else 2


def cmd_lead_desk_packets(args: argparse.Namespace) -> int:
    from .desk_packets import build_desk_packets, write_desk_packets

    store = Path(args.store) if args.store else store_path()
    dest = Path(args.out) if args.out else RESULTS / "live" / "desk-packets"
    note = args.control_note or None
    if args.control_note_file:
        note = Path(args.control_note_file).read_text(encoding="utf-8")
    payload = build_desk_packets(
        store,
        case_id=args.case_id or None,
        control_intent=args.control_intent or None,
        control_owner=args.control_owner or None,
        control_note=note,
        control_transport=getattr(args, "control_transport", None) or TRANSPORT_CONTACTUS,
    )
    write_desk_packets(payload, dest)
    control = payload.get("control") or {}
    binding = control.get("binding") or {}
    safe = {
        "status": "PASS",
        "generated_at": payload.get("generated_at"),
        "store_fingerprint": payload.get("store_fingerprint"),
        "store_unchanged": payload.get("store_unchanged"),
        "case_id": payload.get("case_id"),
        "health_overall": payload.get("health_overall"),
        "queue_count": payload.get("queue_count"),
        "subjects": [item.get("subject") for item in payload.get("emails") or []],
        "out": str(dest),
        "control_json": str(dest / "desk-control.json") if control else None,
        "packet_hash": binding.get("packet_hash"),
        "packet_hash_len": len(str(binding.get("packet_hash") or "")),
        "nonce": binding.get("nonce"),
        "control_selected": bool(control.get("selected")),
        "generate_only": True,
        "public_ingress": False,
        "chatgpt_mcp_mobile": "not_used",
    }
    (RESULTS / "phasef1-packets.json").write_text(json.dumps(safe, indent=2) + "\n", encoding="utf-8")
    _print(safe)
    return 0


def cmd_intake_mode(_args: argparse.Namespace) -> int:
    from .intake_mode import describe_mode

    payload = describe_mode()
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / "intake-mode.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    _print(payload)
    return 0


def cmd_desk_intent(args: argparse.Namespace) -> int:
    from .desk_control import authorize_desk_intent, normalize_desk_intent

    inferred = normalize_desk_intent(
        args.utterance,
        {
            "last_question_kind": args.last_question or None,
            "displayed_case": True,
            "displayed_draft": True,
            "owner": args.owner or "daniel",
        },
    )
    authorized = authorize_desk_intent(inferred)
    payload = {
        "path": "python_utterance_fallback",
        "inferred": inferred,
        "authorized": authorized,
        "execute_send": False,
    }
    _print(payload)
    return 0


def cmd_desk_control(args: argparse.Namespace) -> int:
    from .cases import CaseLayer
    from .desk_bridge import format_result_email, process_control_mail

    store = ReceiptStore(Path(args.store) if args.store else store_path())
    try:
        layer = CaseLayer(store)
        body = args.body
        if args.body_file:
            body = Path(args.body_file).read_text(encoding="utf-8")
        result = process_control_mail(
            layer,
            sender=args.sender,
            subject=args.subject,
            body=body,
            gmail_message_id=args.message_id or None,
        )
    finally:
        store.close()
    RESULTS.mkdir(parents=True, exist_ok=True)
    dest = RESULTS / "live" / "desk-control-result.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    safe = {key: value for key, value in result.items() if key != "result_email"}
    dest.write_text(json.dumps(safe, indent=2, default=str) + "\n", encoding="utf-8")
    email = result.get("result_email") or format_result_email(result)
    (RESULTS / "live" / "desk-control-result.txt").write_text(
        f"Subject: {email['subject']}\n\n{email['body']}",
        encoding="utf-8",
    )
    safe["execute_send"] = False
    _print(safe)
    return 0 if result.get("ok") else 2


def cmd_desk_plus_preflight(_args: argparse.Namespace) -> int:
    from .desk_plus_preflight import plus_control_preflight

    payload = plus_control_preflight()
    RESULTS.mkdir(parents=True, exist_ok=True)
    dest = RESULTS / "live" / "desk-plus-preflight.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(payload, indent=2, default=str) + "\n", encoding="utf-8")
    _print(payload)
    return 0 if payload.get("status") == "READY" else 2


def cmd_desk_plus_poll(args: argparse.Namespace) -> int:
    from .cases import CaseLayer
    from .desk_plus_loop import poll_plus_controls_once

    store = ReceiptStore(Path(args.store) if args.store else store_path())
    try:
        layer = CaseLayer(store)
        payload = poll_plus_controls_once(layer)
    finally:
        store.close()
    RESULTS.mkdir(parents=True, exist_ok=True)
    dest = RESULTS / "live" / "desk-plus-poll.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(payload, indent=2, default=str) + "\n", encoding="utf-8")
    _print(payload)
    if payload.get("reason") == "plus_result_channel_not_ready":
        return 2
    return 0 if payload.get("ok") else 2


def cmd_desk_plus_deliver_results(args: argparse.Namespace) -> int:
    from .cases import CaseLayer
    from .desk_plus_loop import recover_plus_result_sends

    store = ReceiptStore(Path(args.store) if args.store else store_path())
    try:
        layer = CaseLayer(store)
        payload = recover_plus_result_sends(layer)
    finally:
        store.close()
    _print(payload)
    return 0


def cmd_desk_plus_control(args: argparse.Namespace) -> int:
    from .cases import CaseLayer
    from .desk_bridge import format_result_email, process_plus_control_mail

    store = ReceiptStore(Path(args.store) if args.store else store_path())
    try:
        layer = CaseLayer(store)
        result = process_plus_control_mail(layer, gmail_message_id=args.message_id)
    finally:
        store.close()
    RESULTS.mkdir(parents=True, exist_ok=True)
    dest = RESULTS / "live" / "desk-plus-control-result.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    safe = {key: value for key, value in result.items() if key != "result_email"}
    dest.write_text(json.dumps(safe, indent=2, default=str) + "\n", encoding="utf-8")
    email = result.get("result_email") or format_result_email(result)
    (RESULTS / "live" / "desk-plus-control-result.txt").write_text(
        f"Subject: {email['subject']}\n\n{email['body']}",
        encoding="utf-8",
    )
    safe["execute_send"] = False
    safe["customer_send"] = False
    safe["contactus_traffic"] = False
    _print(safe)
    return 0 if result.get("ok") else 2


def cmd_desk_action(args: argparse.Namespace) -> int:
    from .desk_control import submit_desk_action

    if args.json:
        action = json.loads(args.json)
    else:
        action = {"intent": args.intent, "owner": args.owner or None, "note": args.note or None}
    authorized = submit_desk_action(action)
    payload = {
        "path": "chatgpt_structured",
        "action": action,
        "authorized": authorized,
        "execute_send": False,
    }
    _print(payload)
    return 0


def cmd_recover_initial_case_review(args: argparse.Namespace) -> int:
    """Plan or enqueue one allow-listed missed CASEMGR review. Does not send or redraft."""
    from .cases import CaseLayer
    from .desk_bridge import recover_initial_review_for_inbound

    store = ReceiptStore(Path(args.store) if args.store else store_path())
    try:
        layer = CaseLayer(store)
        payload = recover_initial_review_for_inbound(layer, args.gmail_id, enqueue=bool(args.enqueue))
    finally:
        store.close()
    payload["send"] = False
    _print(payload)
    if not payload.get("ok"):
        return 2
    return 0


def cmd_record_local_tests(args: argparse.Namespace) -> int:
    scorecard = empty_scorecard(
        "contactus@ Gmail read-only consent passed. Pub/Sub create is blocked on Cloud admin credentials or console-created topic."
    )
    apply_local_contract_results(scorecard, bool(args.passed), args.output or "")
    write_scorecard(RESULTS / "scorecard.json", scorecard)
    _print({"overall": scorecard["overall"], "gates": {k: v["result"] for k, v in scorecard["gates"].items()}})
    return 0 if args.passed else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="B&T contactus intake proof")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("gate").set_defaults(func=cmd_gate)
    sub.add_parser("setup").set_defaults(func=cmd_setup)
    sub.add_parser("scorecard").set_defaults(func=cmd_scorecard)
    rec = sub.add_parser("record-local-tests")
    rec.add_argument("--passed", action="store_true")
    rec.add_argument("--output", default="")
    rec.set_defaults(func=cmd_record_local_tests)
    sub.add_parser("oauth-url").set_defaults(func=cmd_oauth_url)
    sub.add_parser("cloud-oauth-url").set_defaults(func=cmd_cloud_oauth_url)
    ex = sub.add_parser("oauth-exchange")
    ex.add_argument("redirect", help="localhost redirect URL or code from contactus consent")
    ex.set_defaults(func=cmd_oauth_exchange)
    sub.add_parser("receive-once").set_defaults(func=cmd_receive_once)
    loop = sub.add_parser("receive-loop")
    loop.add_argument("--interval", type=float, default=2.0)
    loop.set_defaults(func=cmd_receive_loop)
    disp = sub.add_parser("write-dispatch-payload")
    disp.add_argument("--message-id", default="")
    disp.add_argument("--nonce", default="")
    disp.set_defaults(func=cmd_write_dispatch_payload)
    sub.add_parser("recover").set_defaults(func=cmd_recover)
    sub.add_parser("phasee-send-oauth-url").set_defaults(func=cmd_phasee_send_oauth_url)
    pex = sub.add_parser("phasee-send-oauth-exchange")
    pex.add_argument("redirect", help="localhost redirect URL or code from contactus send-only consent")
    pex.set_defaults(func=cmd_phasee_send_oauth_exchange)
    pe = sub.add_parser("phasee-execute")
    pe.add_argument("action_id", type=int, help="stored case_send_actions.id; does not auto-select")
    pe.set_defaults(func=cmd_phasee_execute)
    pv = sub.add_parser("phasee-verify")
    pv.add_argument("action_id", type=int, help="stored case_send_actions.id")
    pv.set_defaults(func=cmd_phasee_verify)
    desk = sub.add_parser("lead-desk-packets")
    desk.add_argument("--store", default="", help="readonly SQLite path; defaults to BT_INTAKE_STORE")
    desk.add_argument("--out", default="", help="directory for desk-queue/case/health files")
    desk.add_argument("--case-id", default="", help="optional case to detail; default is newest inbound")
    desk.add_argument("--control-intent", default="", help="generate-only control body; does not send")
    desk.add_argument("--control-owner", default="", help="owner for office_owned generate-only control")
    desk.add_argument("--control-note", default="", help="exact NOTE text for generate-only revise_draft")
    desk.add_argument("--control-note-file", default="", help="read exact NOTE from a UTF-8 file")
    desk.add_argument(
        "--control-transport",
        default=TRANSPORT_CONTACTUS,
        choices=(TRANSPORT_CONTACTUS, TRANSPORT_PLUS),
        help="Generate-only destination. plus_address is internal Lead Desk control only.",
    )
    desk.set_defaults(func=cmd_lead_desk_packets)
    sub.add_parser("intake-mode").set_defaults(func=cmd_intake_mode)
    dc = sub.add_parser("desk-control", help="Process one ChatGPT Gmail control message. Origin is fail-closed without Gmail-fetched evidence. Does not execute a send.")
    dc.add_argument("--sender", default="daniel@btpestcontrol.com")
    dc.add_argument("--subject", default="BT-INTAKE-PROOF-DESK-CTRL-E9A8")
    dc.add_argument("--body", default="")
    dc.add_argument("--body-file", default="")
    dc.add_argument("--message-id", default="")
    dc.add_argument("--store", default="")
    dc.set_defaults(func=cmd_desk_control)
    dpc = sub.add_parser(
        "desk-plus-control",
        help="Process one internal plus-address control fetched from Daniel SENT. Does not send or use contactus@.",
    )
    dpc.add_argument("--message-id", required=True, help="Gmail id in the authenticated daniel@ mailbox")
    dpc.add_argument("--store", default="")
    dpc.set_defaults(func=cmd_desk_plus_control)
    dpp = sub.add_parser(
        "desk-plus-preflight",
        help="Read-only plus-control discovery/sender readiness. Does not change filters or send mail.",
    )
    dpp.set_defaults(func=cmd_desk_plus_preflight)
    dpo = sub.add_parser(
        "desk-plus-poll",
        help="One isolated Daniel history poll. Processes only plus-address revise_draft. Does not use contactus@.",
    )
    dpo.add_argument("--store", default="")
    dpo.add_argument("--once", action="store_true", help="Accepted for systemd oneshot compatibility")
    dpo.set_defaults(func=cmd_desk_plus_poll)
    dpr = sub.add_parser(
        "desk-plus-deliver-results",
        help="Reconcile then send pending plus results. Never contactus@. Not a live-send from this VM.",
    )
    dpr.add_argument("--store", default="")
    dpr.set_defaults(func=cmd_desk_plus_deliver_results)
    da = sub.add_parser("desk-action", help="Primary path: authorize a ChatGPT structured intent. Does not send.")
    da.add_argument("--intent", default="", help="One of the desk intents, e.g. approve_and_send_current")
    da.add_argument("--json", default="", help="Small JSON action from ChatGPT: {intent, owner, note}")
    da.add_argument("--owner", default="")
    da.add_argument("--note", default="")
    da.set_defaults(func=cmd_desk_action)
    di = sub.add_parser("desk-intent", help="Temporary Python fallback if ChatGPT cannot submit a structured action")
    di.add_argument("utterance", help="Raw utterance for the fallback helper only")
    di.add_argument("--last-question", default="", help="offer_send | review_wording | ask_owner")
    di.add_argument("--owner", default="daniel")
    di.set_defaults(func=cmd_desk_intent)
    rec_init = sub.add_parser(
        "recover-initial-case-review",
        help="Bounded recovery for one missed initial CASEMGR CASE packet. Dry-run unless --enqueue. Does not send.",
    )
    rec_init.add_argument("--gmail-id", required=True, help="contactus inbound Gmail id; only 1a096ffa404426f1 is allowed")
    rec_init.add_argument("--store", default="", help="SQLite path; defaults to BT_INTAKE_STORE")
    rec_init.add_argument(
        "--enqueue",
        action="store_true",
        help="Write one current CASE packet to the durable outbox. Still does not send.",
    )
    rec_init.set_defaults(func=cmd_recover_initial_case_review)
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
